"""Utility helpers and configuration."""

