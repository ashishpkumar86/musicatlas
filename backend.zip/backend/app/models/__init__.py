"""Pydantic models used across the API."""

