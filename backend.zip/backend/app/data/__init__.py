# Data access helpers for backend.
