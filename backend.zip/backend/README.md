# music-atlas-backend
FastAPI + TIDAL/MusicBrainz backend for Music Atlas
